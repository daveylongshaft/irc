#!/usr/bin/env python3
"""
Background worker daemon for processing prompts from a queue.

Operates on workorders/wip/ directory:
1. Polls for new prompt files
2. Reads prompt and model directive from YAML front-matter
3. Runs inference (local-ai by default)
4. Journals output to logs/
5. Moves prompt to done/, updates maps, commits, pushes
6. Loops to next prompt

Usage:
    worker-daemon [--model qwen:7b] [--poll-interval 10] [--id 1]

Example prompt structure (workorders/wip/my-task.md):
    ---
    model: qwen:7b
    timeout: 120
    ---
    # My Task
    Generate hello world in Python.
"""

import sys
import time
import subprocess
import json
from pathlib import Path
from datetime import datetime
import re
import argparse
import signal
import os

SCRIPT_DIR = Path(__file__).resolve().parent
CSC_ROOT = SCRIPT_DIR.parent
PROMPTS_WIP = CSC_ROOT / "workorders" / "wip"
PROMPTS_DONE = CSC_ROOT / "workorders" / "done"
LOGS_DIR = CSC_ROOT / "logs"

# Ensure directories exist
PROMPTS_WIP.mkdir(parents=True, exist_ok=True)
PROMPTS_DONE.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)


class WorkerDaemon:
    def __init__(self, worker_id=1, model="qwen:7b", poll_interval=10):
        self.worker_id = worker_id
        self.model = model
        self.poll_interval = poll_interval
        self.running = True
        self.current_job = None

        # Register signal handlers
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

        # Log file
        self.log_file = LOGS_DIR / f"worker-{worker_id}.log"
        self.journal_file = LOGS_DIR / f"worker-{worker_id}.journal"

    def _shutdown(self, signum, frame):
        """Handle shutdown gracefully."""
        self.log(f"Received signal {signum}, shutting down...")
        self.running = False

    def log(self, msg, level="INFO"):
        """Log message to both stdout and file."""
        timestamp = datetime.now().isoformat()
        formatted = f"[{timestamp}] [{level}] {msg}"
        print(formatted)
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(formatted + "\n")
        except Exception as e:
            print(f"[ERROR] Failed to write log: {e}")

    def journal_event(self, event, data=None):
        """Write structured journal entry."""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "worker_id": self.worker_id,
            "event": event,
            "data": data or {}
        }
        try:
            with open(self.journal_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            self.log(f"Failed to write journal: {e}", "WARN")

    def read_front_matter(self, content):
        """Extract YAML front-matter from markdown."""
        if not content.startswith("---"):
            return {}, content

        # Find closing ---
        lines = content.split("\n")
        closing = None
        for i, line in enumerate(lines[1:], 1):
            if line.strip() == "---":
                closing = i
                break

        if closing is None:
            return {}, content

        # Parse YAML manually (simple key: value format)
        fm_lines = lines[1:closing]
        fm = {}
        for line in fm_lines:
            if ":" in line:
                key, val = line.split(":", 1)
                fm[key.strip()] = val.strip()

        rest_content = "\n".join(lines[closing + 1:])
        return fm, rest_content

    def get_pending_prompts(self):
        """Get list of pending prompts from wip/."""
        try:
            prompts = sorted([p for p in PROMPTS_WIP.glob("*.md")])
            return prompts
        except Exception as e:
            self.log(f"Error listing prompts: {e}", "ERROR")
            return []

    def run_prompt(self, prompt_file, model, timeout=600, stall_timeout=120):
        """Execute prompt via local-ai with progress monitoring.

        Args:
            prompt_file: Path to prompt file
            model: Model to use
            timeout: Hard timeout (minutes - for very long tasks)
            stall_timeout: Kill if no output for N seconds
        """
        self.log(f"Starting: {prompt_file.name} (stall timeout: {stall_timeout}s)", "INFO")
        self.journal_event("job_start", {"file": prompt_file.name, "model": model})

        try:
            start_time = time.time()
            last_output_time = start_time
            accumulated_output = ""
            process_killed = False

            # Use Popen for real-time output streaming
            proc = subprocess.Popen(
                ["python", str(SCRIPT_DIR / "local-ai"), str(prompt_file), "--model", model],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,  # Line buffered
                cwd=str(CSC_ROOT)
            )

            try:
                # Stream output and monitor for progress
                while True:
                    line = proc.stdout.readline()
                    if not line:
                        break

                    # Got output - reset stall timer
                    if line.strip():
                        last_output_time = time.time()
                        accumulated_output += line
                        self.log(f"  [MODEL] {line.rstrip()}", "INFO")

                    # Check for total timeout
                    elapsed = time.time() - start_time
                    if elapsed > timeout * 60:
                        self.log(f"Hard timeout reached ({timeout}min), killing process", "WARN")
                        process_killed = True
                        proc.terminate()
                        break

                    # Check for stall (no output for stall_timeout seconds)
                    stall_time = time.time() - last_output_time
                    if stall_time > stall_timeout:
                        self.log(
                            f"Process stalled ({stall_time:.0f}s > {stall_timeout}s), killing and restarting",
                            "WARN"
                        )
                        self.journal_event("job_stalled", {
                            "file": prompt_file.name,
                            "stall_seconds": stall_time
                        })
                        process_killed = True
                        proc.terminate()
                        break

            except Exception as e:
                self.log(f"Error reading process output: {e}", "ERROR")
                proc.terminate()
                return False, accumulated_output, str(e)

            # Wait for process to finish
            try:
                returncode = proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                returncode = -1

            elapsed = time.time() - start_time

            if process_killed:
                self.log(f"Process killed after {elapsed:.1f}s", "ERROR")
                return False, accumulated_output, "Process killed (stalled)"
            elif returncode == 0:
                self.log(f"Completed: {prompt_file.name} in {elapsed:.1f}s", "OK")
                self.journal_event("job_complete", {
                    "file": prompt_file.name,
                    "elapsed": elapsed,
                    "success": True
                })
                return True, accumulated_output, ""
            else:
                self.log(f"Failed: {prompt_file.name} (exit code {returncode})", "ERROR")
                self.journal_event("job_failed", {
                    "file": prompt_file.name,
                    "exit_code": returncode
                })
                return False, accumulated_output, f"Exit code {returncode}"

        except Exception as e:
            self.log(f"Exception: {e}", "ERROR")
            self.journal_event("job_error", {"file": prompt_file.name, "error": str(e)})
            return False, "", str(e)

    def finalize_job(self, prompt_file, output):
        """Move prompt to done/, update maps, commit, push."""
        self.log(f"Finalizing: {prompt_file.name}", "INFO")

        # Move to done/
        try:
            done_file = PROMPTS_DONE / prompt_file.name
            prompt_file.rename(done_file)
            self.log(f"Moved to done/: {prompt_file.name}", "OK")

            # Append output to done file
            with open(done_file, "a", encoding="utf-8") as f:
                f.write("\n\n## Execution Results\n\n")
                f.write(output)

        except Exception as e:
            self.log(f"Failed to move file: {e}", "ERROR")
            return False

        # Update maps
        try:
            self.log("Updating maps...", "INFO")
            result = subprocess.run(
                [sys.executable, str(SCRIPT_DIR / "refresh-maps"), "--quick"],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(CSC_ROOT)
            )
            if result.returncode == 0:
                self.log("Maps updated", "OK")
            else:
                self.log(f"Map refresh failed: {result.stderr}", "WARN")
        except Exception as e:
            self.log(f"Map refresh error: {e}", "WARN")

        # Commit
        try:
            self.log("Committing...", "INFO")
            msg = f"chore: Complete prompt {prompt_file.name}"
            result = subprocess.run(
                ["git", "add", "-A"],
                cwd=str(CSC_ROOT),
                capture_output=True,
                timeout=10
            )
            result = subprocess.run(
                ["git", "commit", "-m", msg],
                cwd=str(CSC_ROOT),
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                self.log(f"Committed: {msg}", "OK")
            else:
                self.log("Nothing to commit (or error)", "INFO")
        except Exception as e:
            self.log(f"Commit error: {e}", "WARN")

        # Push
        try:
            self.log("Pushing...", "INFO")
            result = subprocess.run(
                ["git", "push"],
                cwd=str(CSC_ROOT),
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                self.log("Pushed to remote", "OK")
            else:
                self.log(f"Push failed (may be up to date): {result.stderr}", "INFO")
        except Exception as e:
            self.log(f"Push error: {e}", "WARN")

        self.journal_event("job_finalized", {"file": prompt_file.name})
        return True

    def run(self):
        """Main daemon loop."""
        self.log(f"Worker {self.worker_id} started (model: {self.model}, poll: {self.poll_interval}s)", "INFO")
        self.journal_event("daemon_start", {"model": self.model})

        while self.running:
            try:
                prompts = self.get_pending_prompts()
                if not prompts:
                    # No prompts, sleep and check again
                    time.sleep(self.poll_interval)
                    continue

                # Process first prompt
                prompt_file = prompts[0]
                self.current_job = prompt_file

                # Read front-matter for model/timeout override
                content = prompt_file.read_text(encoding="utf-8")
                fm, _ = self.read_front_matter(content)
                model = fm.get("model", self.model)
                timeout = int(fm.get("timeout", 10))  # In minutes
                stall_timeout = int(fm.get("stall_timeout", 120))  # In seconds

                # Run prompt with stall detection
                success, output, errors = self.run_prompt(
                    prompt_file, model, timeout=timeout, stall_timeout=stall_timeout
                )

                # If successful, finalize
                if success:
                    if not self.finalize_job(prompt_file, output):
                        self.log(f"Finalization failed for {prompt_file.name}", "ERROR")
                else:
                    # On failure, keep in wip/ for retry
                    if "stalled" in errors.lower() or "timeout" in errors.lower():
                        self.log(f"Job stalled/timeout, retry queued: {prompt_file.name}", "WARN")
                        self.journal_event("job_retry_queued", {
                            "file": prompt_file.name,
                            "reason": errors[:100]
                        })
                    else:
                        self.log(f"Job failed, keeping in wip/ for retry: {prompt_file.name}", "WARN")
                        self.journal_event("job_failed_retry", {
                            "file": prompt_file.name,
                            "errors": errors[:200]
                        })
                    if errors:
                        self.log(f"Details: {errors[:200]}", "INFO")

                self.current_job = None

            except KeyboardInterrupt:
                self.log("Interrupted by user", "INFO")
                break
            except Exception as e:
                self.log(f"Unexpected error: {e}", "ERROR")
                self.journal_event("daemon_error", {"error": str(e)})
                time.sleep(5)  # Backoff on error

        self.log(f"Worker {self.worker_id} stopped", "INFO")
        self.journal_event("daemon_stop", {})


def main():
    parser = argparse.ArgumentParser(
        description="Background worker daemon for processing prompts"
    )
    parser.add_argument("--id", type=int, default=1, help="Worker ID (for logging)")
    parser.add_argument("--model", default="qwen:7b", help="Default model to use")
    parser.add_argument("--poll-interval", type=int, default=10, help="Poll interval in seconds")

    args = parser.parse_args()

    daemon = WorkerDaemon(
        worker_id=args.id,
        model=args.model,
        poll_interval=args.poll_interval
    )
    daemon.run()


if __name__ == "__main__":
    main()
