@echo off
REM ============================================================
REM  CSC Test Runner - Docker Service Installer
REM  Builds and starts a Docker container that polls tests
REM  every 60 seconds. Project root is bind-mounted read/write.
REM ============================================================

setlocal
set "CSC_ROOT=%~dp0..\"
set "CONTAINER=csc-test-runner"
set "IMAGE=csc-test-runner:latest"

echo.
echo === CSC Test Runner - Docker Service Installer ===
echo.

REM Check Docker is running
docker info >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Docker is not running.
    echo Start Docker Desktop and try again.
    exit /b 1
)

REM Stop existing container if running
docker stop %CONTAINER% >nul 2>&1
docker rm %CONTAINER% >nul 2>&1

REM Build the image
echo Building image: %IMAGE%
docker build -t %IMAGE% -f "%~dp0test-runner.Dockerfile" "%CSC_ROOT%"
if %errorlevel% neq 0 (
    echo [ERROR] Docker build failed.
    exit /b 1
)
echo.

REM Start the container
echo Starting container: %CONTAINER%
docker run -d ^
    --name %CONTAINER% ^
    --restart unless-stopped ^
    -v "%CSC_ROOT%:/opt/csc" ^
    -w /opt/csc ^
    %IMAGE%

if %errorlevel% neq 0 (
    echo [ERROR] Failed to start container.
    exit /b 1
)

echo.
echo [OK] CSC Test Runner is running in Docker.
echo.
echo Manage with:
echo   docker logs -f %CONTAINER%     Follow logs
echo   docker stop %CONTAINER%        Stop
echo   docker start %CONTAINER%       Start
echo   docker restart %CONTAINER%     Restart
echo.
echo Or use the CLI:
echo   %~dp0..\venv\Scripts\python.exe bin\test-runner start
echo   %~dp0..\venv\Scripts\python.exe bin\test-runner stop
echo   %~dp0..\venv\Scripts\python.exe bin\test-runner status
echo.
echo Log file: logs\test-runner.log
echo.
