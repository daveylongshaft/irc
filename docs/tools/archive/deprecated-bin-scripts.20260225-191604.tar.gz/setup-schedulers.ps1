# Setup automatic task scheduling for CSC background services
# Run as Administrator: powershell -ExecutionPolicy Bypass -File bin/setup-schedulers.ps1

$CSC_ROOT = "C:\csc"
$QW_BAT = "$CSC_ROOT\bin\queue-worker.bat"
$TEST_SCRIPT = "$CSC_ROOT\tests\run_tests.sh"

Write-Host "=== CSC Background Service Scheduler Setup ===" -ForegroundColor Cyan
Write-Host ""

# Check if running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if (-not $isAdmin) {
    Write-Host "ERROR: This script must be run as Administrator" -ForegroundColor Red
    Write-Host "Please run: powershell -ExecutionPolicy Bypass -File bin/setup-schedulers.ps1" -ForegroundColor Yellow
    exit 1
}

Write-Host "Running as Administrator: OK" -ForegroundColor Green
Write-Host ""

# 1. Queue Worker - runs every 2 minutes
Write-Host "1. Setting up Queue Worker (every 2 minutes)..." -ForegroundColor Cyan
$action = New-ScheduledTaskAction -Execute "cmd.exe" -Argument "/c `"cd /d $CSC_ROOT && python bin\queue-worker >> logs\queue-worker.log 2>&1`""
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 2) -RepetitionDuration (New-TimeSpan -Days 36500)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false

try {
    Register-ScheduledTask `
        -TaskName "CSC Queue Worker" `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -Force `
        -ErrorAction Stop | Out-Null
    Write-Host "  ✓ Queue Worker scheduled" -ForegroundColor Green
}
catch {
    Write-Host "  ✗ Error scheduling Queue Worker: $_" -ForegroundColor Red
}

Write-Host ""

# 2. Test Runner - runs every 5 minutes
Write-Host "2. Setting up Test Runner (every 5 minutes)..." -ForegroundColor Cyan
$testCmd = "cd $CSC_ROOT; bash tests/run_tests.sh >> logs/test-runner.log 2>&1"
$action = New-ScheduledTaskAction -Execute "bash.exe" -Argument "-c '$testCmd'"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 5) -RepetitionDuration (New-TimeSpan -Days 36500)
$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -RunOnlyIfNetworkAvailable:$false

try {
    Register-ScheduledTask `
        -TaskName "CSC Test Runner" `
        -Action $action `
        -Trigger $trigger `
        -Settings $settings `
        -Force `
        -ErrorAction Stop | Out-Null
    Write-Host "  ✓ Test Runner scheduled" -ForegroundColor Green
}
catch {
    Write-Host "  ✗ Error scheduling Test Runner: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "=== Setup Complete ===" -ForegroundColor Green
Write-Host ""
Write-Host "Scheduled Tasks:"
Write-Host "  1. CSC Queue Worker - Every 2 minutes (queue processing & wrapper spawning)"
Write-Host "  2. CSC Test Runner  - Every 5 minutes (test execution with auto-fix prompts)"
Write-Host ""
Write-Host "To manage tasks:"
Write-Host "  - View:   taskschd.msc or schtasks /query /tn 'CSC*'"
Write-Host "  - Delete: schtasks /delete /tn 'CSC Queue Worker' /f"
Write-Host "  - Logs:   $CSC_ROOT\logs\queue-worker.log"
Write-Host "  - Logs:   $CSC_ROOT\logs\test-runner.log"
