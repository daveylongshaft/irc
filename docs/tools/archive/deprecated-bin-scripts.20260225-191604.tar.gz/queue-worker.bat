@echo off
REM Queue Worker Batch Wrapper for Windows Task Scheduler
cd /d "%~dp0..\"
%~dp0..\venv\Scripts\python.exe "%~dp0queue-worker" %*
