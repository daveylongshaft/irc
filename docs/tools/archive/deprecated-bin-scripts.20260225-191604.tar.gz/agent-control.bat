@echo off
%~dp0..\venv\Scripts\python.exe "%~dp0agent-control.py" %*
