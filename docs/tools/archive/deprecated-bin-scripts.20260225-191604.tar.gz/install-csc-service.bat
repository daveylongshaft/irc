@echo off
echo Building csc-service Docker image...
docker compose build csc-service
echo Starting csc-service...
docker compose up -d csc-service
echo.
echo csc-service is running. Check logs with:
echo   docker compose logs -f csc-service
