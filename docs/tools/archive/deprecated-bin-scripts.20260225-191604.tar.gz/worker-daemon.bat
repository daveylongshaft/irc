@echo off
%~dp0..\venv\Scripts\python.exe "%~dp0worker-daemon.py" %*
