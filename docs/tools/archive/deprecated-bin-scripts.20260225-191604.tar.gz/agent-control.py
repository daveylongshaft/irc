#!/usr/bin/env python3
"""
Agent Control - Manage agent services and queues.

Usage:
    agent-control setup <agent-name>           Create new agent
    agent-control start <agent-name>           Start agent service
    agent-control stop <agent-name>            Stop agent service
    agent-control status <agent-name>          Show agent status
    agent-control queue <agent-name>           Show queue status
    agent-control logs <agent-name> [--follow] Show agent logs
    agent-control submit <agent-name> <prompt> Submit task to agent
    agent-control list                         List all agents

Examples:
    agent-control setup code-reviewer
    agent-control start code-reviewer
    agent-control status code-reviewer
    agent-control submit code-reviewer "Review this Python code..."
    agent-control logs code-reviewer --follow
    agent-control list
"""

import sys
import json
import subprocess
import time
from pathlib import Path
from datetime import datetime
import argparse

SCRIPT_DIR = Path(__file__).resolve().parent
CSC_ROOT = SCRIPT_DIR.parent
AGENTS_DIR = CSC_ROOT / "agents"


def log(msg, level="INFO"):
    """Print log message."""
    symbols = {
        "OK": "[OK]",
        "WARN": "[!]",
        "FAIL": "[X]",
        "INFO": "[*]"
    }
    sym = symbols.get(level, "[*]")
    print(f"{sym} {msg}")


def agent_exists(agent_name):
    """Check if agent exists."""
    return (AGENTS_DIR / agent_name).exists()


def cmd_setup(agent_name, desc="", model="qwen:7b"):
    """Set up new agent."""
    if agent_exists(agent_name):
        log(f"Agent '{agent_name}' already exists", "WARN")
        return False

    result = subprocess.run(
        [sys.executable, str(SCRIPT_DIR / "agent-setup.py"), agent_name,
         "--desc", desc, "--model", model],
        cwd=str(CSC_ROOT)
    )
    return result.returncode == 0


def cmd_start(agent_name, poll_interval=60):
    """Start agent service (checks queue every N seconds, default 60s)."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    log(f"Starting agent '{agent_name}' (poll: {poll_interval}s)...", "INFO")

    # Platform-specific service startup
    if sys.platform == "win32":
        # Windows: use pythonw for background execution
        subprocess.Popen(
            [sys.executable, str(SCRIPT_DIR / "agent-service.py"), agent_name],
            cwd=str(CSC_ROOT),
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
        )
    else:
        # Linux/Mac: use nohup
        subprocess.Popen(
            ["nohup", sys.executable, str(SCRIPT_DIR / "agent-service.py"), agent_name],
            cwd=str(CSC_ROOT),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            preexec_fn=lambda: os.setpgrp() if hasattr(os, 'setpgrp') else None
        )

    time.sleep(1)
    log(f"Agent '{agent_name}' started", "OK")
    return True


def cmd_stop(agent_name):
    """Stop agent service."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    log(f"Stopping agent '{agent_name}'...", "INFO")

    # Find and kill processes
    if sys.platform == "win32":
        subprocess.run(
            ["taskkill", "/F", "/FI", f"COMMANDLINE=*agent-service*{agent_name}*"],
            capture_output=True
        )
    else:
        subprocess.run(
            ["pkill", "-f", f"agent-service.*{agent_name}"],
            capture_output=True
        )

    log(f"Agent '{agent_name}' stopped", "OK")
    return True


def cmd_status(agent_name):
    """Show agent status."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    agent_dir = AGENTS_DIR / agent_name
    state_file = agent_dir / "state.json"

    print(f"\n{'='*60}")
    print(f"AGENT: {agent_name}")
    print(f"{'='*60}\n")

    # Load state
    if state_file.exists():
        try:
            state = json.loads(state_file.read_text())
            for key, val in state.items():
                print(f"  {key:.<30} {val}")
        except Exception as e:
            log(f"Error reading state: {e}", "WARN")

    # Queue status
    queue_in = agent_dir / "queue" / "in"
    queue_work = agent_dir / "queue" / "work"
    queue_out = agent_dir / "queue" / "out"

    pending = len(list(queue_in.glob("*.json"))) if queue_in.exists() else 0
    processing = len(list(queue_work.glob("*.json"))) if queue_work.exists() else 0
    completed = len(list(queue_out.glob("*.json"))) if queue_out.exists() else 0

    print(f"\n  Queue Status:")
    print(f"    Pending:  {pending}")
    print(f"    Processing: {processing}")
    print(f"    Completed:  {completed}")

    print(f"\n{'='*60}\n")
    return True


def cmd_queue(agent_name):
    """Show detailed queue status."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    agent_dir = AGENTS_DIR / agent_name

    for queue_name, queue_dir in [("PENDING", "in"), ("PROCESSING", "work"), ("COMPLETED", "out")]:
        queue_path = agent_dir / "queue" / queue_dir
        if not queue_path.exists():
            continue

        tasks = sorted(queue_path.glob("*.json"))
        print(f"\n{queue_name} ({len(tasks)}):")
        for task in tasks:
            try:
                data = json.loads(task.read_text())
                preview = data.get("content", "")[:50].replace("\n", " ")
                print(f"  - {task.stem}: {preview}...")
            except Exception:
                print(f"  - {task.stem}: [read error]")

    return True


def cmd_logs(agent_name, follow=False):
    """Show agent logs."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    log_file = CSC_ROOT / "logs" / "agents" / agent_name / "service.log"

    if not log_file.exists():
        log(f"No logs found for '{agent_name}'", "WARN")
        return False

    if follow:
        log(f"Following logs (Ctrl+C to stop)...\n", "INFO")
        try:
            if sys.platform == "win32":
                # Windows: tail -f emulation
                last_size = 0
                while True:
                    current_size = log_file.stat().st_size
                    if current_size > last_size:
                        with open(log_file, "r", encoding="utf-8") as f:
                            f.seek(last_size)
                            print(f.read(), end="")
                        last_size = current_size
                    time.sleep(1)
            else:
                subprocess.run(["tail", "-f", str(log_file)])
        except KeyboardInterrupt:
            print("\nStopped")
    else:
        with open(log_file, "r", encoding="utf-8") as f:
            lines = f.readlines()
            print("".join(lines[-100:]))  # Last 100 lines

    return True


def cmd_submit(agent_name, prompt):
    """Submit a task to agent queue."""
    if not agent_exists(agent_name):
        log(f"Agent '{agent_name}' not found", "FAIL")
        return False

    agent_dir = AGENTS_DIR / agent_name
    queue_in = agent_dir / "queue" / "in"

    # Create task
    task_id = datetime.now().strftime("%Y%m%d-%H%M%S")
    task_data = {
        "id": task_id,
        "submitted": datetime.now().isoformat(),
        "content": prompt,
        "model": None,  # Use agent default
        "timeout": None,  # Use default
        "stall_timeout": None  # Use default
    }

    task_file = queue_in / f"{task_id}.json"
    task_file.write_text(json.dumps(task_data, indent=2))

    log(f"Task submitted: {task_id}", "OK")
    print(f"  Queue: {queue_in.relative_to(CSC_ROOT)}")
    print(f"  Check status: agent-control status {agent_name}")

    return True


def cmd_list():
    """List all agents."""
    if not AGENTS_DIR.exists():
        log("No agents directory found", "INFO")
        return False

    agents = [d.name for d in AGENTS_DIR.iterdir() if d.is_dir()]

    if not agents:
        log("No agents configured", "INFO")
        return False

    print(f"\nConfigured Agents ({len(agents)}):\n")
    for agent in sorted(agents):
        agent_dir = AGENTS_DIR / agent
        state_file = agent_dir / "state.json"

        status = "unknown"
        if state_file.exists():
            try:
                state = json.loads(state_file.read_text())
                tasks = state.get("tasks_processed", 0)
                status = f"{tasks} tasks processed"
            except Exception:
                pass

        print(f"  - {agent:.<30} {status}")

    print()
    return True


def main():
    parser = argparse.ArgumentParser(
        description="Agent Control - Manage agent services",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # setup
    sp = subparsers.add_parser("setup", help="Create new agent")
    sp.add_argument("agent_name")
    sp.add_argument("--desc", default="")
    sp.add_argument("--model", default="qwen:7b")

    # start/stop
    subparsers.add_parser("start", help="Start agent service").add_argument("agent_name")
    subparsers.add_parser("stop", help="Stop agent service").add_argument("agent_name")

    # status/queue/logs
    subparsers.add_parser("status", help="Show agent status").add_argument("agent_name")
    subparsers.add_parser("queue", help="Show queue details").add_argument("agent_name")
    sp = subparsers.add_parser("logs", help="Show agent logs")
    sp.add_argument("agent_name")
    sp.add_argument("--follow", action="store_true", help="Follow logs")

    # submit
    sp = subparsers.add_parser("submit", help="Submit task to agent")
    sp.add_argument("agent_name")
    sp.add_argument("prompt", nargs="+")

    # list
    subparsers.add_parser("list", help="List all agents")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    # Handle commands
    if args.command == "setup":
        success = cmd_setup(args.agent_name, args.desc, args.model)
    elif args.command == "start":
        success = cmd_start(args.agent_name)
    elif args.command == "stop":
        success = cmd_stop(args.agent_name)
    elif args.command == "status":
        success = cmd_status(args.agent_name)
    elif args.command == "queue":
        success = cmd_queue(args.agent_name)
    elif args.command == "logs":
        success = cmd_logs(args.agent_name, args.follow)
    elif args.command == "submit":
        success = cmd_submit(args.agent_name, " ".join(args.prompt))
    elif args.command == "list":
        success = cmd_list()
    else:
        parser.print_help()
        return 1

    return 0 if success else 1


if __name__ == "__main__":
    import os
    sys.exit(main())
