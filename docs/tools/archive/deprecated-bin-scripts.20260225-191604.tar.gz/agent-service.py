#!/usr/bin/env python3
"""
Agent Service - Queue-based task processor running as system service.

Each agent has:
- queue/in/        → Incoming tasks
- queue/work/      → Currently processing
- queue/out/       → Completed tasks
- context/         → System instructions and context files
- state.json       → Agent state and metadata

Usage:
    agent-service <agent-name> [--poll-interval 60]

    Runs as system service, processes queue/in/ → queue/work/ → queue/out/
    Default: Checks queue once per minute (light on system resources)

Example:
    agent-service code-reviewer
    agent-service doc-generator --poll-interval 10  # Check every 10s if needed
"""

import sys
import json
import time
import subprocess
import os
import signal
from pathlib import Path
from datetime import datetime
import argparse
import threading

# Get CSC root
SCRIPT_DIR = Path(__file__).resolve().parent
CSC_ROOT = SCRIPT_DIR.parent
AGENTS_DIR = CSC_ROOT / "agents"


class AgentService:
    def __init__(self, agent_name, poll_interval=60):
        self.agent_name = agent_name
        self.poll_interval = poll_interval
        self.running = True
        self.current_pids = {}  # task_id → process info

        # Agent directories
        self.agent_dir = AGENTS_DIR / agent_name
        self.queue_in = self.agent_dir / "queue" / "in"
        self.queue_work = self.agent_dir / "queue" / "work"
        self.queue_out = self.agent_dir / "queue" / "out"
        self.context_dir = self.agent_dir / "context"
        self.state_file = self.agent_dir / "state.json"

        # Logs
        self.log_dir = CSC_ROOT / "logs" / "agents" / agent_name
        self.log_file = self.log_dir / "service.log"

        # Create directories
        for d in [self.queue_in, self.queue_work, self.queue_out, self.context_dir, self.log_dir]:
            d.mkdir(parents=True, exist_ok=True)

        # Register signal handlers
        signal.signal(signal.SIGINT, self._shutdown)
        signal.signal(signal.SIGTERM, self._shutdown)

        # Load state
        self.state = self._load_state()

    def _shutdown(self, signum, frame):
        """Graceful shutdown."""
        self.log(f"Received signal {signum}, shutting down...", "WARN")
        self.running = False

    def log(self, msg, level="INFO"):
        """Log to file and stdout."""
        timestamp = datetime.now().isoformat()
        formatted = f"[{timestamp}] [{level}] {msg}"
        print(formatted)
        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(formatted + "\n")
        except Exception as e:
            print(f"[ERROR] Failed to write log: {e}")

    def _load_state(self):
        """Load or create agent state."""
        if self.state_file.exists():
            try:
                return json.loads(self.state_file.read_text())
            except Exception:
                pass

        return {
            "agent": self.agent_name,
            "started": datetime.now().isoformat(),
            "tasks_processed": 0,
            "tasks_failed": 0,
            "current_task": None
        }

    def _save_state(self):
        """Save agent state."""
        self.state["updated"] = datetime.now().isoformat()
        try:
            self.state_file.write_text(json.dumps(self.state, indent=2))
        except Exception as e:
            self.log(f"Failed to save state: {e}", "ERROR")

    def load_context(self):
        """Load all context files from context/ directory."""
        context = ""
        context_files = sorted(self.context_dir.glob("*.md")) + \
                       sorted(self.context_dir.glob("*.txt")) + \
                       sorted(self.context_dir.glob("*.json"))

        for ctx_file in context_files:
            try:
                content = ctx_file.read_text(encoding="utf-8")
                context += f"\n=== {ctx_file.name} ===\n{content}\n"
            except Exception as e:
                self.log(f"Failed to load context {ctx_file.name}: {e}", "WARN")

        return context

    def get_pending_tasks(self):
        """Get list of pending tasks from queue/in/."""
        try:
            tasks = sorted([t for t in self.queue_in.glob("*.json") if t.is_file()])
            return tasks
        except Exception as e:
            self.log(f"Error listing tasks: {e}", "ERROR")
            return []

    def run_task(self, task_file):
        """Execute a task from queue."""
        task_id = task_file.stem
        self.log(f"Processing task: {task_id}", "INFO")

        # Load task
        try:
            task_data = json.loads(task_file.read_text())
        except Exception as e:
            self.log(f"Failed to read task {task_id}: {e}", "ERROR")
            return False

        # Move to work/
        work_file = self.queue_work / task_file.name
        try:
            task_file.rename(work_file)
        except Exception as e:
            self.log(f"Failed to move task to work: {e}", "ERROR")
            return False

        # Load context
        context = self.load_context()

        # Build prompt: context + task
        prompt_text = context + "\n\n=== TASK ===\n" + task_data.get("content", "")

        # Get model and options from task
        model = task_data.get("model", "qwen:7b")
        timeout = int(task_data.get("timeout", 10))
        stall_timeout = int(task_data.get("stall_timeout", 120))

        # Prepare temporary prompt file
        temp_prompt = CSC_ROOT / "tmp" / f"task-{task_id}.md"
        temp_prompt.parent.mkdir(parents=True, exist_ok=True)
        temp_prompt.write_text(prompt_text)

        # Spawn worker process via local-ai with streaming
        try:
            self.log(f"Spawning worker: {model}, timeout: {timeout}m, stall: {stall_timeout}s", "INFO")

            proc = subprocess.Popen(
                [sys.executable, str(SCRIPT_DIR / "local-ai"), str(temp_prompt),
                 "--model", model, "--stream"],
                cwd=str(CSC_ROOT),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1
            )

            # Record in state
            self.current_pids[task_id] = {
                "pid": proc.pid,
                "started": datetime.now().isoformat(),
                "model": model,
                "work_file": str(work_file),
                "temp_prompt": str(temp_prompt)
            }

            # Update task work file with PID
            work_data = task_data.copy()
            work_data["pid"] = proc.pid
            work_data["started"] = datetime.now().isoformat()
            work_file.write_text(json.dumps(work_data, indent=2))

            self.log(f"Task {task_id} spawned: PID {proc.pid}", "OK")
            self._save_state()

            return True

        except Exception as e:
            self.log(f"Failed to spawn worker for {task_id}: {e}", "ERROR")
            self.state["tasks_failed"] += 1
            self._save_state()
            return False

    def poll_processes(self):
        """Check status of running processes."""
        completed = []

        for task_id, proc_info in list(self.current_pids.items()):
            pid = proc_info["pid"]
            work_file = Path(proc_info["work_file"])

            # Check if process still running
            try:
                # Try to get process (doesn't kill it)
                if sys.platform == "win32":
                    result = subprocess.run(
                        ["tasklist", "/FI", f"PID eq {pid}"],
                        capture_output=True,
                        timeout=2
                    )
                    running = str(pid) in result.stdout.decode()
                else:
                    result = subprocess.run(
                        ["ps", "-p", str(pid)],
                        capture_output=True,
                        timeout=2
                    )
                    running = result.returncode == 0
            except Exception:
                running = False

            # If finished, move to out/
            if not running:
                try:
                    # Read work file for results
                    work_data = json.loads(work_file.read_text())

                    # Move to out/
                    out_file = self.queue_out / work_file.name
                    work_data["completed"] = datetime.now().isoformat()
                    work_data["exit_status"] = "completed"
                    out_file.write_text(json.dumps(work_data, indent=2))
                    work_file.unlink()

                    # Clean up temp prompt
                    temp_prompt = Path(proc_info["temp_prompt"])
                    if temp_prompt.exists():
                        temp_prompt.unlink()

                    self.log(f"Task {task_id} completed (PID {pid})", "OK")
                    self.state["tasks_processed"] += 1
                    completed.append(task_id)

                except Exception as e:
                    self.log(f"Error finalizing task {task_id}: {e}", "ERROR")
                    self.state["tasks_failed"] += 1

        # Remove completed from tracking
        for task_id in completed:
            del self.current_pids[task_id]

        if completed:
            self._save_state()

    def run(self):
        """Main service loop."""
        self.log(f"Agent service '{self.agent_name}' started (poll: {self.poll_interval}s)", "INFO")
        self._save_state()

        while self.running:
            try:
                # Check existing processes
                self.poll_processes()

                # Get new tasks
                pending = self.get_pending_tasks()

                if pending:
                    for task_file in pending:
                        if self.running:
                            self.run_task(task_file)
                            time.sleep(0.5)

                # Sleep before next poll
                time.sleep(self.poll_interval)

            except KeyboardInterrupt:
                self.log("Interrupted by user", "WARN")
                break
            except Exception as e:
                self.log(f"Unexpected error: {e}", "ERROR")
                time.sleep(self.poll_interval)

        self.log(f"Agent service '{self.agent_name}' stopped", "INFO")
        self._save_state()


def main():
    parser = argparse.ArgumentParser(
        description="Agent Service - Queue-based task processor"
    )
    parser.add_argument("agent_name", help="Agent name (directory under agents/)")
    parser.add_argument("--poll-interval", type=int, default=5, help="Poll interval in seconds")

    args = parser.parse_args()

    # Verify agent directory exists
    agent_dir = AGENTS_DIR / args.agent_name
    if not agent_dir.exists():
        print(f"[ERROR] Agent directory not found: {agent_dir}")
        print(f"Create it with: agent-setup {args.agent_name}")
        sys.exit(1)

    # Run service
    service = AgentService(args.agent_name, args.poll_interval)
    service.run()


if __name__ == "__main__":
    main()
