@echo off
REM Setup CSC background service tasks
REM Run as Administrator

setlocal enabledelayedexpansion

echo.
echo === CSC Background Service Scheduler Setup ===
echo.

REM Check for admin privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: This batch file must be run as Administrator
    echo.
    echo Right-click Command Prompt and select "Run as administrator"
    echo Then run: bin\setup-tasks.bat
    exit /b 1
)

echo Running as Administrator: OK
echo.

REM 1. Queue Worker - every 2 minutes
echo 1. Creating Queue Worker task (every 2 minutes)...
schtasks /create /tn "CSC Queue Worker" ^
    /tr "cmd /c cd /d C:\csc && %~dp0..\venv\Scripts\python.exe bin\queue-worker >> logs\queue-worker.log 2>&1" ^
    /sc minute /mo 2 /f >nul 2>&1
if %errorlevel% equ 0 (
    echo   [OK] Queue Worker scheduled
) else (
    echo   [ERROR] Failed to create Queue Worker task
)

echo.

REM 2. Test Runner - every 1 minute
echo 2. Creating Test Runner task (every 1 minute)...
schtasks /create /tn "CSC Test Runner" ^
    /tr "cmd /c cd /d C:\csc && %~dp0..\venv\Scripts\python.exe bin\test-runner >> logs\test-runner.log 2>&1" ^
    /sc minute /mo 1 /f >nul 2>&1
if %errorlevel% equ 0 (
    echo   [OK] Test Runner scheduled
) else (
    echo   [ERROR] Failed to create Test Runner task
)

echo.
echo === Setup Complete ===
echo.
echo Scheduled Tasks:
echo   1. CSC Queue Worker - Every 2 minutes (queue processing)
echo   2. CSC Test Runner  - Every 1 minute (test execution)
echo.
echo To verify tasks:
echo   schtasks /query /tn "CSC*"
echo.
echo To view logs:
echo   logs\queue-worker.log
echo   logs\test-runner.log
echo.
echo To delete tasks:
echo   schtasks /delete /tn "CSC Queue Worker" /f
echo   schtasks /delete /tn "CSC Test Runner" /f
echo.
