@echo off
REM ============================================================
REM  CSC Test Runner - Docker Service Uninstaller
REM  Stops and removes the csc-test-runner container and image.
REM ============================================================

setlocal
set "CONTAINER=csc-test-runner"
set "IMAGE=csc-test-runner:latest"

echo.
echo === CSC Test Runner - Docker Service Uninstaller ===
echo.

REM Stop container
echo Stopping container...
docker stop %CONTAINER% >nul 2>&1

REM Remove container
echo Removing container...
docker rm %CONTAINER% >nul 2>&1

REM Remove image
echo Removing image...
docker rmi %IMAGE% >nul 2>&1

echo.
echo [OK] CSC Test Runner removed.
echo.
