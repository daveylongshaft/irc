@echo off
echo Stopping csc-service...
docker compose down
echo Done.
