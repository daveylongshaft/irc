#!/usr/bin/env python3
"""
CSC Agent Launcher & Tracker

Launches AI agents on federation tasks and tracks their progress.
Monitors WIP files for journal entries and git commits.

Usage:
    python agent-launcher.py opus
    python agent-launcher.py haiku
    python agent-launcher.py track
    python agent-launcher.py status
"""

import sys
import os
import subprocess
import time
import json
from pathlib import Path
from datetime import datetime


class AgentTracker:
    """Track agent progress on federation tasks."""

    def __init__(self, csc_root=None):
        if csc_root is None:
            csc_root = Path(__file__).parent.parent
        self.csc_root = Path(csc_root)
        self.wip_dir = self.csc_root / "workorders" / "wip"
        self.done_dir = self.csc_root / "workorders" / "done"
        self.log_dir = self.csc_root / "logs"
        self.log_dir.mkdir(exist_ok=True)

        self.tasks = {
            "opus": {
                "file": "opus-server-linking-federation.md",
                "model": "opus",
                "description": "Server Linking & Federation System"
            },
            "haiku-config": {
                "file": "haiku-configure-official-csc-server.md",
                "model": "haiku",
                "description": "Configure Official Server"
            },
            "haiku-sync": {
                "file": "haiku-time-sync-for-server-merges.md",
                "model": "haiku",
                "description": "Time Synchronization for Server Merges"
            },
            "haiku-collision": {
                "file": "haiku-nick-collision-resolution.md",
                "model": "haiku",
                "description": "Nick Collision Resolution"
            }
        }

    def get_wip_file(self, task_name):
        """Get WIP file path for task."""
        if task_name in self.tasks:
            return self.wip_dir / self.tasks[task_name]["file"]
        raise ValueError(f"Unknown task: {task_name}")

    def get_progress(self, task_name):
        """Get progress stats for a task."""
        wip_file = self.get_wip_file(task_name)

        if not wip_file.exists():
            return {"status": "not_started", "lines": 0, "entries": 0}

        try:
            with open(wip_file, 'r') as f:
                content = f.read()
                lines = len(content.splitlines())

            # Count journal entries (lines that look like actions)
            entries = 0
            last_entry = None
            for line in content.splitlines():
                if line and not line.startswith('#') and not line.startswith('['):
                    if any(line.startswith(verb) for verb in ['reading', 'modifying', 'creating', 'checking', 'testing', 'implementing', 'running', 'verifying']):
                        entries += 1
                        last_entry = line[:80]

            return {
                "status": "in_progress",
                "lines": lines,
                "entries": entries,
                "last_entry": last_entry
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    def print_status(self):
        """Print status of all tasks."""
        print("\n" + "=" * 70)
        print("CSC FEDERATION AGENT STATUS")
        print("=" * 70)
        print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

        for task_id, task_info in self.tasks.items():
            progress = self.get_progress(task_id)
            wip_file = self.get_wip_file(task_id)

            print(f"[{task_id.upper()}] {task_info['description']}")
            print(f"  File: {task_info['file']}")
            print(f"  Model: {task_info['model']}")

            if progress["status"] == "in_progress":
                print(f"  Status: IN PROGRESS")
                print(f"  Lines: {progress['lines']} | Journal entries: {progress['entries']}")
                if progress.get("last_entry"):
                    print(f"  Last action: {progress['last_entry']}")
            elif progress["status"] == "not_started":
                print(f"  Status: READY (not started)")
                if wip_file.exists():
                    print(f"  Lines: {progress['lines']}")
            else:
                print(f"  Status: ERROR - {progress.get('error')}")

            # Check if task moved to done
            done_file = self.done_dir / task_info["file"]
            if done_file.exists():
                print(f"  Status: COMPLETED ✓")

            print()

    def launch_agent(self, task_name):
        """Launch agent on a task."""
        if task_name not in self.tasks:
            print(f"Unknown task: {task_name}")
            return False

        task_info = self.tasks[task_name]
        wip_file = self.get_wip_file(task_name)
        model = task_info["model"]

        if not wip_file.exists():
            print(f"WIP file not found: {wip_file}")
            return False

        print(f"\n{'=' * 70}")
        print(f"LAUNCHING: {task_info['description']}")
        print(f"{'=' * 70}")
        print(f"Task: {task_name}")
        print(f"Model: {model}")
        print(f"File: {wip_file.name}")
        print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"\nSystem Prompt:")
        print("-" * 70)

        system_prompt = (
            "MANDATORY: Journal every step to the WIP file BEFORE doing it. "
            "Run: echo '<what you are about to do>' >> workorders/wip/{} ".format(wip_file.name) +
            "BEFORE each action. No checkboxes. No Edit tool. Just echo one line per step. "
            "Example: echo 'read version_service.py' >> workorders/wip/{} ".format(wip_file.name) +
            "NEVER DELETE WIP FILES. Always move them to workorders/done/ when finished. "
            "This is NON-NEGOTIABLE. Journal progress frequently."
        )

        print(system_prompt)
        print("-" * 70)
        print()

        # Launch claude CLI
        try:
            cmd = [
                "claude",
                "-p",
                "--dangerously-skip-permissions",
                "--model", model,
                "--append-system-prompt", system_prompt,
                str(wip_file)
            ]

            print(f"Command: {' '.join(cmd)}\n")
            print("Agent is now working on this task...")
            print("Check progress with: python agent-launcher.py status")
            print()

            # Run in background
            log_file = self.log_dir / f"agent-{task_name}.log"
            with open(log_file, 'w') as f:
                process = subprocess.Popen(
                    cmd,
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    cwd=self.csc_root
                )

            print(f"Agent PID: {process.pid}")
            print(f"Log file: {log_file}")
            print()

            return True

        except FileNotFoundError:
            print("ERROR: claude CLI not found. Install with: pip install claude")
            return False
        except Exception as e:
            print(f"ERROR: Failed to launch agent: {e}")
            return False

    def watch_progress(self, interval=30, max_iterations=120):
        """Watch agent progress in real-time."""
        print(f"\n{'=' * 70}")
        print("WATCHING AGENT PROGRESS")
        print(f"{'=' * 70}")
        print(f"Interval: {interval}s | Max iterations: {max_iterations}")
        print("(Ctrl+C to stop)\n")

        for iteration in range(max_iterations):
            try:
                os.system('clear' if os.name != 'nt' else 'cls')

                print(f"Update {iteration + 1}/{max_iterations} - {datetime.now().strftime('%H:%M:%S')}\n")

                all_done = True
                for task_id, task_info in self.tasks.items():
                    progress = self.get_progress(task_id)
                    done_file = self.done_dir / task_info["file"]

                    if done_file.exists():
                        print(f"✓ {task_id}: COMPLETED")
                    elif progress["status"] == "in_progress":
                        print(f"→ {task_id}: {progress['entries']} entries | {progress['lines']} lines")
                        if progress.get("last_entry"):
                            print(f"    {progress['last_entry'][:60]}...")
                        all_done = False
                    else:
                        print(f"○ {task_id}: WAITING")
                        all_done = False

                if all_done:
                    print(f"\n{'=' * 70}")
                    print("ALL TASKS COMPLETED!")
                    print(f"{'=' * 70}")
                    return True

                print()
                if iteration < max_iterations - 1:
                    print(f"Next check in {interval}s (Ctrl+C to stop)...")
                    time.sleep(interval)

            except KeyboardInterrupt:
                print("\nStopped by user")
                return False

        print("\nWatch timeout reached")
        return False


def main():
    if len(sys.argv) < 2:
        print("Usage: agent-launcher.py <command>")
        print()
        print("Commands:")
        print("  opus              Launch Opus on server linking")
        print("  haiku             Launch all Haiku tasks (one at a time)")
        print("  status            Show current progress")
        print("  track             Watch progress in real-time")
        print()
        sys.exit(1)

    command = sys.argv[1]
    tracker = AgentTracker()

    if command == "status":
        tracker.print_status()

    elif command == "track":
        tracker.watch_progress()

    elif command == "opus":
        success = tracker.launch_agent("opus")
        if success:
            print("\nTo track progress:")
            print("  python agent-launcher.py status")
            print("  python agent-launcher.py track")

    elif command == "haiku":
        print("\nLaunching Haiku agents one by one...")
        tasks = ["haiku-config", "haiku-sync", "haiku-collision"]

        for i, task in enumerate(tasks, 1):
            print(f"\n[{i}/3] Launching {task}...")
            tracker.launch_agent(task)

            if i < len(tasks):
                print(f"\nWaiting 30 seconds before next task...")
                time.sleep(30)

        print("\nAll Haiku tasks launched!")
        print("Track progress with: python agent-launcher.py track")

    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
